STREET FIGHTER II' CHAMPION RE-EDIT
version: 0.32
release date: 23/10/2026
site: https://sf2cre.blogspot.com/
youtube: https://www.youtube.com/@sf2cre

Playable via Final Burn Neo latest nightly build:
https://github.com/finalburnneo/FBNeo/releases

